// Author: Praveen Rao
#ifndef _NODEPARAMS_H_
#define _NODEPARAMS_H_

#include <chord.h>
// index node related defs
const int MAXENTRIES = 300;
chordID LEAF, NONLEAF, ROOT;

enum InsertType {
  UPDATE = -1,
  SPLIT = -2,
  UPDATEHDRLOCK = -3,
  UPDATEHDR = -4,
  NONE = -5,
  REPLACE = -6,
  SPLITSPECIAL = -7,
  REPLACESIG = -8,
  UPDATEIFPRESENT = -9
};
#endif

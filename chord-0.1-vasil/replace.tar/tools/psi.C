// Psi - Peer-to-peer Signature Index. Twig Query processing in P2P Environments.
// Author: Praveen Rao
// University of Arizona/University of Missouri-Kansas City
#include "psi.h"
#include <chord.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dhash_common.h>
#include <dhashclient.h>
#include <dhblock.h>
#include <dhblock_keyhash.h>
#include <sys/time.h>
#include <string>
#include <math.h>
#include <iostream>
#include "poly.h"
#include "utils.h"
#include <vector>
#include <map>
#include <utility>
#include "utils.C"
#include "nodeparams.h"
#include "cache.h"

dhashclient *dhash;
int out;

DHTStatus insertDocument(str&, std::vector<POLY>&, int, int, int, int, int);
DHTStatus insertDocument(str&, std::vector<POLY>&, int);
str pickChild(vec<str>&, std::vector<POLY>&);
void splitNode(vec<str>&, std::vector<int>&, std::vector<int>&,
							 std::vector<POLY>&);
void getKey(str&, str&);
void getKeyValue(str&, str&, str&);
void makeKeyValue(char **, int&, str&, std::vector<POLY>&,
									InsertType);
void makeKeyValue(char **, int&, str&, Interval&,
									InsertType);
void makeKeyValue(char **, int&, vec<str>&, std::vector<int>&,
									InsertType);
DHTStatus insertDHT(chordID, char *, int);

DHTStatus performSplit(chordID, Interval&, chordID);

DHTStatus performSplitRoot(chordID, Interval&);
int pSim(std::vector<POLY>&, std::vector<POLY>&,
				 std::vector<POLY>&, bool);
//void queryProcess(std::vector<str>&, std::vector<POLY>&);
//void queryProcess(str&, std::vector<std::vector<POLY> >&, int, int, int);
void queryProcess(str&, std::vector<std::vector<POLY> >&);
void verifyProcess(char *, std::vector<std::vector<POLY> >&, int);
DHTStatus mergeProcess(str&, std::vector<POLY>&);
int getNumReplicas(int, int);

DHTStatus insertStatus;
vec<chordID> fullNodeIDs;
std::vector<Interval> fullNodeInts;

// entries of a node
vec<str> nodeEntries;

bool insertError;
bool retrieveError;

// hash table statistics
int numReads;
int numWrites;
int numDocs;
int cacheHits;

// pSim
bool metric;

// to avoid repeated node visits during query processing
// can happen due to concurrent operations
// can be avoided by periodic cleanup
std::map<std::string, bool> listOfVisitedNodes;

// Node split related stuff
std::vector<int> group1, group2;
std::vector<POLY> lcm1, lcm2;

unsigned int seedForRand;

// Hash table to store nodes that are full, just serves as a cache!!!
std::map<std::string, bool> cacheOfFullNodes;

// For verification
std::map<int, std::vector<int> > docMatchList;

// Data transfered
int dataFetched = 0, dataStored = 0;

// Fetch callback for NOAUTH...
void
fetch_cb (dhash_stat stat, ptr<dhash_block> blk, vec<chordID> path)
{
    out++;

	if (stat != DHASH_OK) {
		warnx << "Failed to fetch key...\n";
		retrieveError = true;
		return;
	}

    if (blk) {
        strbuf buf;
        
#ifdef _DEBUG_
        buf << " /times=";
        for (u_int i = 0; i < blk->times.size (); i++)
            buf << " " << blk->times[i];
        buf << " /";
        
        buf << "hops= " << blk->hops << " errors= " <<  blk->errors
            << "vretries= " << blk->retries << " ";
		buf << " path: ";
        for (u_int i=0; i < path.size (); i++) {
            buf << path[i] << " ";
        }
        
        buf << " : ";
        
#endif
        if (blk->vData.size () > 0) {
            //warn << blk->vData.size () << "\n";
            
            for (unsigned int i = 0; i < blk->vData.size (); i++) {
                nodeEntries.push_back(blk->vData[i]);
                dataFetched += nodeEntries[i].len();
            }
        }
        else {
            nodeEntries.push_back(blk->data);
        }
        
        // Output hops
        warnx << "HOPS: " << blk->hops << "\n";
        numReads++;
        
#ifdef _DEBUG_ 
        warnx << "Retrieve information: " << buf << "\n";
#endif
    }
}

void
store_cb (dhash_stat status, ptr<insert_info> i)
{
  out++;

  if (status == DHASH_NOTFIRST) {
    insertStatus = NOTFIRST;
  }
  else if (status != DHASH_OK) {
    warnx << "Failed to store key...\n";
    insertError = true;
  }
  else {
    numWrites++;
    warnx << "Key stored successfully...\n";
  }
}


int main(int argc, char *argv[]) {
	
  if(argc < 7) {
		std::cout << "Usage: " << argv[0]
							<< " sockname " // argv[1]
							<< " -[dDiqvM] "  // argv[2]
							<< " signaturefile|#oflevels|level " // argv[3]
							<< " fanout|verifyqueryfile " // argv[4]
							<< " count " // argv[5]
							<< " irrpolydegree " // argv[6]
							<< " <metric=1|gcd=0> " // argv[7]
							<< " <cache size> " // argv[8]
							<< std::endl;
		exit(1);
	}

	char *cmd = argv[2];
	
	if (!strcmp(cmd, "-v")) {
		dhash = NULL;
	}
	else {
		dhash = New dhashclient(argv[1]);
	}
        chordID ID;

	// pSim metric
	metric = argv[7] ? (bool) atoi(argv[7]) : false;
		
	// Cache size
	cacheSize = argv[8] ? atoi(argv[8]) : 1;
	freeSpace = cacheSize;
	
	// Initialize node types
	LEAF = compute_hash(LEAFNODE, strlen(LEAFNODE));
	NONLEAF = compute_hash(NONLEAFNODE, strlen(NONLEAFNODE));
	ROOT = compute_hash(ROOTNODE, strlen(ROOTNODE));

	int maxCount = atoi(argv[5]);
	int irrPolyDegree = atoi(argv[6]);
	int randDelay = atoi(argv[4]);

	warnx << "Irreducible polynomial degree: " << irrPolyDegree << "\n";
	warnx << "Fan out: " << MAXENTRIES << "\n";
	
	// Time measurement
	double startTime = getgtod();
	seedForRand = (unsigned int) startTime;
	
	numReads = numWrites = dataReadSize = cacheHits = 0;

	// Compute the root node key for the tree
	chordID rootNodeID = compute_hash(ROOTNODEID, strlen(ROOTNODEID));
	warnx << "Root node id: " << rootNodeID << "\n";
        
	
  if (!strcmp(cmd, "-d")) {
		// Dump an index that has a root and a single leaf
		
		Interval leafInt;
		leafInt.ln = 0;
		leafInt.ld = 1;
		leafInt.rn = 1;
		leafInt.rd = 1;
		leafInt.level = 0;

		char tempBuf[128];
		sprintf(tempBuf, "%d.%d.%d", leafInt.level, leafInt.ln,
						leafInt.ld);
		chordID leafID;
		leafID = compute_hash(tempBuf, strlen(tempBuf));
		
		char *hdrVal;
		int hdrLen;

		strbuf lType;
		lType << LEAF;
		str leafType(lType);

		makeKeyValue(&hdrVal, hdrLen, leafType, leafInt, UPDATEHDR);

		// Leaf node
		DHTStatus stat = insertDHT(leafID, hdrVal, hdrLen);
		cleanup(hdrVal);

		Interval rootInt;
		rootInt.ln = 0;
		rootInt.ld = 1;
		rootInt.rn = 1;
		rootInt.rd = 1;
		rootInt.level = 1;

		strbuf rType;
		rType << ROOT;
		str rootType(rType);
		
		makeKeyValue(&hdrVal, hdrLen, rootType, rootInt, UPDATEHDR);
		stat = insertDHT(rootNodeID, hdrVal, hdrLen);
		cleanup(hdrVal);
		
		char *value;
		int valLen;

		std::vector<POLY> sig;
		sig.push_back(0x1);

		strbuf sBuf;
		sBuf << leafID;
		str leafIDStr(sBuf);
		
		makeKeyValue(&value, valLen, leafIDStr, sig, UPDATE);

		// Root node
		stat = insertDHT(rootNodeID, value, valLen);
		cleanup(value);
		
	}
	else if (!strcmp(cmd, "-M")) {
		strbuf s;
		s << rootNodeID;
		str rootID(s);
		std::vector<POLY> sig;
		sig.push_back(0x1);
		DHTStatus stat = mergeProcess(rootID, sig);
		if (stat == FAIL) {
			warnx << "Failed to perform merge properly.\n";
		}
	}
	else if (!strcmp(cmd, "-q")) {
		double totalTime = 0;
		// Cache tree nodes
		nodeCache.clear();
		lruCache.clear();
		// Read the query signatures from a file
		// Read the DHT from root to leaf
		std::string queryFile(argv[3]);
		FILE *qfp = fopen(queryFile.c_str(), "r");
		assert(qfp);

		int count = 1;
		
		while (count <= maxCount) {

			// DON'T use readData to retrieve signatures from input files...
			// since the size filed uses POLY as a basic unit and not byte...
			// Format is <n = # of sigs><sig size><sig>... n times...
			int numSigs;
			if (fread(&numSigs, sizeof(numSigs), 1, qfp) != 1) {
				break;
			}
			assert(numSigs > 0);

			std::vector<std::vector<POLY> > listOfSigs;
			listOfSigs.clear();
			
			for (int t = 0; t < numSigs; t++) {
				POLY *buf;
				int size;
				if (fread(&size, sizeof(int), 1, qfp) != 1) {
					assert(0);
				}
				
				buf = new POLY[size];
				assert(buf);
				if (fread(buf, sizeof(POLY), size, qfp) != (size_t) size) {
					assert(0);
				}
				
				std::vector<POLY> sig;
				sig.clear();
				for (int i = 0; i < size; i++) {
					sig.push_back(buf[i]);
				}

				listOfSigs.push_back(sig);
				// free the allocated memory
				delete[] buf;
			}
			
			warnx << "******* Processing query " << count << " ********\n";
			numReads = numWrites = dataReadSize = cacheHits = 0;
			strbuf s;
			s << rootNodeID;
			str rootID(s);

			warnx << "Number of signatures: " << listOfSigs.size() << "\n";
			if ((int) listOfSigs.size() > MAXSIGSPERQUERY) {
				warnx << "Skipping this query...\n";
			}
			else {
				numDocs = 0;
				listOfVisitedNodes.clear();
				
				double beginQueryTime = getgtod();
				queryProcess(rootID, listOfSigs);
				double endQueryTime = getgtod();
				std::cout << "Query time: " << endQueryTime - beginQueryTime << std::endl;
				totalTime += (endQueryTime - beginQueryTime);
				warnx << "Num docs: " << numDocs << "\n";
			}
			
#ifdef _DEBUG_
			
#endif
			warnx << "Data read: " << dataFetched << "\n";
            warnx << "Data write: " << dataStored << "\n";
			warnx << "Num reads: " << numReads << "\n";
			//warnx << " num writes: " << numWrites << "\n";
			warnx << "Cache hits: " << cacheHits << "\n";
			warnx << "******** Finished query processing *********\n\n\n";
			count++;

			//if (count % 2 == 0) {
			//	sleep(1);
			//}
			if (1) {
                sleep(1 + (int) ((double) randDelay * (rand() / (RAND_MAX + 1.0))));
			}
		}
		
		fclose(qfp);
		std::cout << "Time taken: " << totalTime << std::endl;
	}
	else if (!strcmp(cmd, "-v")) {
		// Read the query signatures from a file
		// Read the DHT from root to leaf
		std::string queryFile(argv[4]);
		FILE *qfp = fopen(queryFile.c_str(), "r");
		assert(qfp);

		int count = 1;
		while (count <= maxCount) {

			// DON'T use readData to retrieve signatures from input files...
			// since the size filed uses POLY as a basic unit and not byte...
			// Format is <n = # of sigs><sig size><sig>... n times...
			int numSigs;
			if (fread(&numSigs, sizeof(numSigs), 1, qfp) != 1) {
				break;
			}
			assert(numSigs > 0);

			std::vector<std::vector<POLY> > listOfSigs;
			listOfSigs.clear();
			
			for (int t = 0; t < numSigs; t++) {
				POLY *buf;
				int size;
				if (fread(&size, sizeof(int), 1, qfp) != 1) {
					assert(0);
				}
				
				buf = new POLY[size];
				assert(buf);
				if (fread(buf, sizeof(POLY), size, qfp) != (size_t) size) {
					assert(0);
				}
				
				std::vector<POLY> sig;
				sig.clear();
				for (int i = 0; i < size; i++) {
					sig.push_back(buf[i]);
				}

				listOfSigs.push_back(sig);
				// free the allocated memory
				delete[] buf;
			}
			
			//if ((int) listOfSigs.size() > MAXSIGSPERQUERY) {
			if (0) {
				warnx << "Skipping query verification...\n";
			}
			else {
				// Verify the query signature(s) with the data signatures!
				verifyProcess(argv[3], listOfSigs, count);
			}
			//warnx << "******** Finished verifying queries *********\n\n\n";
			count++;
			
		}

		// print the docMatchList
		for (std::map<int, std::vector<int> >::iterator itr = docMatchList.begin();
				 itr != docMatchList.end(); itr++) {
			for (int i = 0; i < (int) itr->second.size(); i++) {
				std::cout << itr->second[i] << " ";
			}
			std::cout << "\n";
		}
		
		fclose(qfp);
	}
	else if (!strcmp(cmd, "-i")) {
		// Insert new signatures
		std::string dataFile(argv[3]);
		FILE *sigfp = fopen(dataFile.c_str(), "r");
		assert(sigfp);

		int count = 1;
		while (count <= maxCount) {

			// DONT use readData to retrieve signatures from input files...
			// since the size filed uses POLY as a basic unit and not byte...
			// Read numSigs <it should be 1> for data signatures...
			int numSigs;
			if (fread(&numSigs, sizeof(int), 1, sigfp) != 1) {
				break;
			}
            warnx << "NUM sigs: " << numSigs << "\n";
			assert(numSigs == 1);
			
			int size;
			
			if (fread(&size, sizeof(int), 1, sigfp) != 1) {
				assert(0);
			}

			warnx << "Signature size: " << size << "\n";

			std::vector<POLY> sig;
			sig.clear();
			POLY e;
			for (int i = 0; i < size; i++) {
				if (fread(&e, sizeof(POLY), 1, sigfp) != 1) {
					assert(0);
				}
				sig.push_back(e);
			}

			// Read the document id
			int docId;
			if (fread(&docId, sizeof(docId), 1, sigfp) != 1) {
				assert(0);
			}

            warnx << "**********************************************************\n";
			warnx << "*            Inserting document " << docId << " ********\n";
            warnx << "**********************************************************\n";
			// ROOT node id			
			strbuf s;
			s << rootNodeID;
			str rootID(s);
			DHTStatus status;

			warnx << "ROOT ID: " << rootID << "\n";
#ifdef _DEBUG_
			for (int l = 0; l < (int) sig.size(); l++) {
				warnx << sig[l] << " ";
			}
			warnx << "\n";
#endif
			while (1) {

                // Keep track of full nodes and their headers
                fullNodeIDs.clear();
                fullNodeInts.clear();
                
				status = insertDocument(rootID, sig, docId);

				if (status == REINSERT) {
					sleep(5);
					warnx << "Reinsert in progress...\n";
				}
				else {
					break;
				}
			}
			
			if (status == SUCC) {
				warnx << "***** Finished document insert successfully *******\n";
			}
			else if (status == FAIL) {
				warnx << "*+*+*+* Document insert FAILED *+*+*+*\n";
			}
			else if (status == FULL) {
				warnx << "*-*-*-* Index is full!!!! *-*-*-*\n";
				break;
			}
			
			count++;
			
			if (1) {
                sleep(1 + (int) ((double) randDelay * (rand() / (RAND_MAX + 1.0))));
			}
		}
		
		fclose(sigfp);
        warnx << "Data read: " << dataFetched << "\n";
        warnx << "Data write: " << dataStored << "\n";
		warnx << "Number of documents inserted: " << count - 1 << "\n";
		warnx << "Number of full nodes: " << cacheOfFullNodes.size() << "\n";
		double finishTime = getgtod();
		
		std::cout << "Time taken: " << finishTime - startTime << std::endl;
	}
	else {
		fatal("Invalid option\n");
  }

  //double finishTime = getgtod();
		
  //std::cout << "Time taken: " << finishTime - startTime << std::endl;
  //amain(); Asynchronous interface, requires probably exit()
  // from callbacks. eg. if (inflight == 0) exit(0);
  return 0;
}

// Verification process, the set of correct matches...
void verifyProcess(char *fileName, std::vector<std::vector<POLY> >& listOfSigs,
									 int queryid)
{
	int numMatches = 0;
	FILE *sigfp = fopen(fileName, "r");

	std::vector<POLY> oldSig;
	std::vector<POLY> sig;
	
	int loopCount = 0;

	while (1) {
		int numSigs;
		if (fread(&numSigs, sizeof(int), 1, sigfp) != 1) {
			break;
		}
		assert(numSigs == 1);
		
		int size;
		
		if (fread(&size, sizeof(int), 1, sigfp) != 1) {
			assert(0);
		}

		// clear old sig
		sig.clear();
		POLY e;
		for (int i = 0; i < size; i++) {
			if (fread(&e, sizeof(POLY), 1, sigfp) != 1) {
				assert(0);
			}
			sig.push_back(e);
		}

		int docId;
		if (fread(&docId, sizeof(docId), 1, sigfp) != 1) {
			assert(0);
		}

		int dega = getDegree(sig);
		
		//warnx << "Deg a: " << dega << "\n";
		for (int j = 0; j < (int) listOfSigs.size(); j++) {
			std::vector<POLY> rem;
			// Test for divisibility!!!
			rem.clear();

			int degb = getDegree(listOfSigs[j]);

			//warnx << "Deg b: " << degb << "\n";
			
			if (dega >= degb) {
				//remainder(rem, sig, listOfSigs[j]);
				//double beginTime = getgtod();
				remainder(rem, sig, listOfSigs[j]);
				//double endTime = getgtod();
				//std::cerr << "REM time: " << endTime - beginTime << "\n";
			}

			if (rem.size() == 1 && rem[0] == (POLY) 0) {
				//warnx << "==== Found match ==== DOCID: " << docId << "\n";
				//warnx << docId << "\n";
				std::map<int, std::vector<int> >::iterator titr;
				titr = docMatchList.find(loopCount);
				
				if (titr != docMatchList.end()) {
					titr->second.push_back(queryid);
					
				}
				else {
					std::vector<int> e;
					e.push_back(queryid);
					docMatchList[loopCount] = e;
				}
				
				numMatches++;
				break;
			}
		}

		// If any document if not matched, just add an empty entry
		if (docMatchList.find(loopCount) == docMatchList.end()) {
			std::vector<int> e;
			docMatchList[loopCount] = e;
		}
		
		loopCount++;
	}

	fclose(sigfp);
}

// Update the top level so called MBR to take splits into consideration.
DHTStatus mergeProcess(str& nodeID, std::vector<POLY>& sig)
{
	sleep(1);
	vec<str> myNodeEntries;
	chordID ID;
	str2chordID(nodeID, ID);

	nodeEntries.clear();
	// now fetch the node
	out = 0;
	retrieveError = false;
	
	dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));

	while (out == 0) acheck();

	if (retrieveError) {
		warnx << "Failed to retrieve key during insertion...\n";
		return FAIL;
	}

	// Copy it -- currently no other solution
	myNodeEntries = nodeEntries;

	str a, b;
	Interval nodeInt;
	chordID nodeType;
	warnx << "# of node entries: " << myNodeEntries.size() << "\n";
	
	getKeyValue(myNodeEntries[0], a, b);

	str2chordID(a, nodeType);
	getInterval(b, nodeInt);

	DHTStatus status = FAIL;

	if (nodeType == LEAF) {
		str myKey;
		std::vector<POLY> mySig;
		
		for (int i = 1; i < (int) myNodeEntries.size(); i++) {
			myKey = "";
			mySig.clear();
			getKeyValue(myNodeEntries[i].cstr(), myKey, mySig);
			lcm(sig, mySig);
		}

		status = SUCC;
	}
	else {
		std::vector<POLY> myChildSig, tempSig;
		str myChildKey;
				
		for (int i = 1; i < (int) myNodeEntries.size(); i++) {
			myChildSig.clear();
			myChildSig.push_back(0x1);

			getKeyValue(myNodeEntries[i].cstr(), myChildKey, tempSig);
			
			status = mergeProcess(myChildKey, myChildSig);

			if (status == FAIL) break;

			// If signature needs to be updated, then yes!
			if (myChildSig != tempSig) {
				char *value;
				int valLen;
					
				makeKeyValue(&value, valLen, myChildKey, myChildSig, REPLACESIG);

				DHTStatus stat = insertDHT(ID, value, valLen);
				cleanup(value);
				
				if (stat == FAIL) {
					status = FAIL;
					break;
				}

				// Degree of the signature for analysis purpose
				warnx << "BEFORE sig degree: " << getDegree(tempSig)
							<< " AFTER sig degree: " << getDegree(myChildSig)
							<< "\n";
			}

			// To send to parent
			lcm(sig, myChildSig);
		}
	}

	return status;
}

// Computes the similarity between two signatures
int pSim(std::vector<POLY>& s1, std::vector<POLY>& s2,
    std::vector<POLY>& mygcd, bool isMetric)
{
	int retVal;
	if (isMetric) {
        std::vector<POLY> mylcm;
		mylcm.push_back((POLY) 0x1);
		lcm(mylcm, s1);
		lcm(mylcm, s2);
		double val = (double) (INT_MAX-1) * getDegree(mygcd) / getDegree(mylcm);
		retVal = (int) val;
	}
	else {
		retVal = getDegree(mygcd);
	}
	//warnx << "PSim: " << retVal << "\n";
	return retVal;
}

// Pick the best child
// Tie-breaking strategies not EMPLOYED YET!!!
str pickChild(vec<str>& nodeEntries, std::vector<POLY>& sig)
{
	std::vector<POLY> entrySig;
	std::vector<POLY> gcdPoly;
	int maxGCDDegree = -1;
	int sigDegree, bestChildSigDegree = -1;
	str bestChild = "NULL";
	str childKey;

	//warnx << "# of node entries for pick child: "
	//			<< nodeEntries.size() << "\n";
	
	// The first entry has the nodetype/interval
	for (int i = 1; i < (int) nodeEntries.size(); i++) {
		childKey = "";
		entrySig.clear();
		getKeyValue(nodeEntries[i].cstr(), childKey, entrySig);

		// degree of this signature
		sigDegree = getDegree(entrySig);
		
		// First compute GCD with the entry to be inserted
		gcdPoly.clear();
		
		// Compute GCD
		gcdSpecial(gcdPoly, entrySig, sig);
		
        int deg = pSim(entrySig, sig, gcdPoly, metric);
		//warnx << "Pick child degree: " << deg << "\n";
		if (deg > maxGCDDegree) {
			maxGCDDegree = deg;
			bestChild = childKey;
			bestChildSigDegree = sigDegree;
		}
		else if (deg == maxGCDDegree) {
			// Choose the smallest degree signature.
			// For split nodes, till they are fixed properly.
			// tie breaker
			if (sigDegree < bestChildSigDegree) {
				bestChild = childKey;
				bestChildSigDegree = sigDegree;
			}
		}
	}

	return bestChild;
}


// Split a node
void splitNode(vec<str>& entries,
    std::vector<int>& group1,
    std::vector<int>& group2,
    std::vector<POLY>& lcm1,
    std::vector<POLY>& lcm2)
{
	std::vector<std::vector<POLY> > sigList;
	vec<str> IDList;
	
	str ID, sigStr;
	std::vector<POLY> s;

    assert(entries.size() > 0);

	// Read in the signatures
	for (int i = 1; i < (int) entries.size(); i++) {
		getKeyValue(entries[i], ID, sigStr);
        //warnx << "Check id: " << ID << "\n";
		IDList.push_back(ID);
		s.clear();

		POLY *sigPtr = (POLY *) sigStr.cstr();
		for (int j = 0; j < (int) sigStr.len()/(int) sizeof(POLY); j++) {
			s.push_back(sigPtr[j]);
		}
		sigList.push_back(s);
	}

	std::multimap<int, int> sortedSigList;
	// Sort them based on degree
	for (int i = 0; i < (int) sigList.size(); i++) {
		int deg = getDegree(sigList[i]);
        //warnx << "Check degree: " << deg << "\n";
		sortedSigList.insert(std::pair<int, int>(deg, i));
	}
	
	int seed1 = -1, seed2 = -1;
	std::vector<POLY> gcdPoly;
	int minDeg = INT_MAX;
	
	// Find the two most dissimilar
	//for (int i = 0; i < sigList.size() - 1; i++) {
	std::multimap<int, int>::iterator endItrI = sortedSigList.end();
	endItrI--;
	
	for (std::multimap<int, int>::iterator itrI = sortedSigList.begin();
			 itrI != endItrI; itrI++) {
		itrI++;
		std::multimap<int, int>::iterator itrJ = itrI;
		itrI--;
		
		for (; itrJ != sortedSigList.end(); itrJ++) {
			gcdPoly.clear();
			gcdSpecial(gcdPoly, sigList[itrI->second], sigList[itrJ->second]);

			//int deg = getDegree(gcdPoly);
			int deg = pSim(sigList[itrI->second], sigList[itrJ->second], gcdPoly,
										 metric);
            //warnx << "Degree: " << deg << "\n";
			if (deg < minDeg) {
				seed1 = itrI->second;
				seed2 = itrJ->second;
				minDeg = deg;
			}
			
			if (deg < 0) break;
		}
	}

	group1.push_back(seed1+1);
	group2.push_back(seed2+1);

    //warnx << "SEED1 : " << seed1
    //      << "  SEED2 : " << seed2
    //      << "\n";
	lcm1 = sigList[seed1];
	lcm2 = sigList[seed2];

	std::vector<POLY> gcd1, gcd2;
	
	//for (int i = 0; i < sigList.size(); i++) {
	for (std::multimap<int, int>::iterator itr = sortedSigList.begin();
			 itr != sortedSigList.end(); itr++) {
		if (itr->second == seed1 || itr->second == seed2) continue;

		gcd1.clear();
		gcd2.clear();
		
		gcdSpecial(gcd1, lcm1, sigList[itr->second]);
		gcdSpecial(gcd2, lcm2, sigList[itr->second]);

		//int deg1 = getDegree(gcd1);
		//int deg2 = getDegree(gcd2);
		int deg1 = pSim(lcm1, sigList[itr->second], gcd1, metric);
		int deg2 = pSim(lcm2, sigList[itr->second], gcd2, metric);

		if (deg1 > deg2) {
			lcm(lcm1, sigList[itr->second]);
			group1.push_back(itr->second+1);
		}
		else if (deg1 < deg2) {
			lcm(lcm2, sigList[itr->second]);
			group2.push_back(itr->second+1);
		}
		else {
			if (group1.size() <= group2.size()) {
				lcm(lcm1, sigList[itr->second]);
				group1.push_back(itr->second+1);
			}
			else {
				lcm(lcm2, sigList[itr->second]);
				group2.push_back(itr->second+1);
			}
		}		
	}
	/*
	// Print the two groups
	warnx << "GROUP 1 \n";
	for (int i = 0; i < (int) group1.size(); i++) {
		warnx << group1[i] << " ";
	}

	warnx << "\n";
	
	warnx << "GROUP 2 \n";
	for (int i = 0; i < (int) group2.size(); i++) {
		warnx << group2[i] << " ";
	}

	warnx << "\n";
	*/
	return;
}

DHTStatus insertDHT(chordID ID, char *value, int valLen)
{
	warnx << "Storing key: " << ID << "\n";
	out = 0;
	insertError = false;
    insertStatus = SUCC;

    dataStored += valLen;
    
	dhash->insert(ID, (char *) value, valLen, wrap(store_cb), NULL, DHASH_NOAUTH);
	while (out == 0) acheck();
	
	if (insertError) {
		warnx << "Error during INSERT operation...\n";
		return FAIL;
	}

	return insertStatus;
}


// split the root node with only one peer authorized to do it
DHTStatus performSplitRoot(chordID ID, Interval& oldInt)
{
    vec<str> entries;
	
    nodeEntries.clear();
	// now fetch the node
	out = 0;
	retrieveError = false;
	
	dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));

	while (out == 0) acheck();

	if (retrieveError) {
		warnx << "Failed to retrieve key during insertion...\n";
		return FAIL;
	}

	// Copy it -- currently no other solution
	entries = nodeEntries;

    // Already split!!! so don't do anything more...
    if ((int) entries.size() <= MAXENTRIES) {
        return FAIL;
    }
    
	str nodeType, b;
	Interval nodeInt;
		
    getKeyValue(entries[0], nodeType, b);

	getInterval(b, nodeInt);

    // Test the old header seen and what is seen now...
    if (oldInt != nodeInt) {
        return FAIL;
    }

	// split the node
	group1.clear();
	group2.clear();
	lcm1.clear();
	lcm2.clear();

#ifdef _DEBUG_
	// Printing the node
	warnx << "------> ";
	for (int i = 0; i < (int) entries.size(); i++) {
		warnx << entries[i] << "        ";
	}
	warnx << "\n";
#endif
	
	splitNode(entries, group1, group2, lcm1, lcm2);

	// Original node ask it to delete the second part...
	// The new node, make sure it does not have the first part...
	// Then we can guarantee eventual correctness guarantee...
			
    // Key - already known
	// Format of value - <type=SPLIT><interval><group1><group2>
	Interval firstNodeInt, secondNodeInt, myInt;
	firstNodeInt.ln = 0;
	firstNodeInt.ld = 1;
	firstNodeInt.rn = 1;
	firstNodeInt.rd = 2;
	firstNodeInt.level = nodeInt.level;

	secondNodeInt.ln = 1;
	secondNodeInt.ld = 2;
	secondNodeInt.rn = 1;
	secondNodeInt.rd = 1;
	secondNodeInt.level = nodeInt.level;

    myInt.ln = nodeInt.ln;
    myInt.ld = nodeInt.ld;
    myInt.rn = nodeInt.rn;
    myInt.rd = nodeInt.rd;
    myInt.level = nodeInt.level + 1;

	
    // Key - new key from Interval -- includes level information
	// for uniqueness
	char tempBuf[128];
	sprintf(tempBuf, "%d.%d.%d", firstNodeInt.level, firstNodeInt.ln, firstNodeInt.ld);
	chordID firstNodeID;
	firstNodeID = compute_hash(tempBuf, strlen(tempBuf));
	strbuf s;
	s << firstNodeID;
	str firstChildID = str(s);
			
	char *value;
	int valLen;

	char *hdrVal;
	int hdrLen;

    strbuf s1;
	s1 << NONLEAF;
	str nonLeafType(s1);
	makeKeyValue(&hdrVal, hdrLen, nonLeafType, firstNodeInt, UPDATEHDRLOCK);

    warnx << "-------------- Performing Root Split ------------------\n";
	// step 1: Create sibling node
		
	DHTStatus stat = insertDHT(firstNodeID, hdrVal, hdrLen);
	cleanup(hdrVal);

	if (stat == FAIL) return FAIL;

    // This peer has authority to finish the split
    if (stat != NOTFIRST) {
        // step 2: Insert contents to the newly created node...
        makeKeyValue(&value, valLen, entries, group1, SPLIT);

        stat = insertDHT(firstNodeID, value, valLen);
        cleanup(value);

        if (stat == FAIL) return FAIL;

        // step 3: Create the second node
        sprintf(tempBuf, "%d.%d.%d", secondNodeInt.level, secondNodeInt.ln, secondNodeInt.ld);
        chordID secondNodeID;
        secondNodeID = compute_hash(tempBuf, strlen(tempBuf));

        strbuf s2;
        s2 << secondNodeID;
        str secondChildID(s2);
        
        makeKeyValue(&hdrVal, hdrLen, nonLeafType, secondNodeInt, UPDATEHDR);
        
        		
        DHTStatus stat = insertDHT(secondNodeID, hdrVal, hdrLen);
        cleanup(hdrVal);
        
        if (stat == FAIL) return FAIL;

        // step 4: Insert contents to the newly created node...
        makeKeyValue(&value, valLen, entries, group2, SPLIT);

        stat = insertDHT(secondNodeID, value, valLen);
        cleanup(value);

        if (stat == FAIL) return FAIL;
        
        // step 5: Next delete all the contents from the original node
        std::vector<int> group3 = group1;
        for (int i = 0; i < (int) group2.size(); i++) {
            group3.push_back(group2[i]);
        }
        makeKeyValue(&value, valLen, entries, group3, SPLIT);
        
        stat = insertDHT(ID, value, valLen);
        cleanup(value);
        
        if (stat == FAIL) return FAIL;


        // step 6: Now add links to the two new children
        makeKeyValue(&value, valLen, firstChildID, lcm1, UPDATE);
        stat = insertDHT(ID, value, valLen);
        cleanup(value);
        if (stat == FAIL) return FAIL;
        
        makeKeyValue(&value, valLen, secondChildID, lcm2, UPDATE);
        stat = insertDHT(ID, value, valLen);
        cleanup(value);
        if (stat == FAIL) return FAIL;
        
        // step 7: Update the header of the original node
        makeKeyValue(&hdrVal, hdrLen, nodeType, myInt, UPDATEHDR);
        
        stat = insertDHT(ID, hdrVal, hdrLen);
        cleanup(hdrVal);
        if (stat == FAIL) return FAIL;
    }
    else if (stat == NOTFIRST) { // Will await header change
        int waitInterval = 1;
        vec<str> myNodeEntries;
        
        while (1) {
            sleep(waitInterval);
            out = 0;
            nodeEntries.clear();
            retrieveError = false;
            
            dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));
            
            while (out == 0) acheck();
            
            if (retrieveError) {
                warnx << "Unable to read node " << ID << "\n";
                return FAIL;
            }
            
            //warnx << "Number of entries: " << nodeEntries.size() << "\n";

            // Copy it -- currently no other solution
            myNodeEntries.clear();
            myNodeEntries = nodeEntries;

            str a, b;
            Interval mynodeInt;

            //warnx << "# of node entries: " << myNodeEntries.size() << "\n";
            
            getKeyValue(myNodeEntries[0], a, b);
            
            getInterval(b, mynodeInt);

            // Check the header for change
            if (nodeInt == mynodeInt) {
                waitInterval *= 2;    
            }
            else {
                warnx << "------ Root header has changed ------\n";
                break;
            }
            
        }
    }

	return NODESPLIT;
}

// Perform non root node splits
DHTStatus performSplit(chordID ID, Interval& oldInt, chordID pID)
{
    vec<str> entries;
	
    nodeEntries.clear();
	// now fetch the node
	out = 0;
	retrieveError = false;
	
	dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));

	while (out == 0) acheck();

	if (retrieveError) {
		warnx << "Failed to retrieve key during insertion...\n";
		return FAIL;
	}

	// Copy it -- currently no other solution
	entries = nodeEntries;

    // Already split!!! so don't do anything more...
    if ((int) entries.size() <= MAXENTRIES) {
        return FAIL;
    }
    
	str nodeType, b;
	Interval nodeInt;
		
    getKeyValue(entries[0], nodeType, b);

	getInterval(b, nodeInt);

    // Test the old header seen and what is seen now
    if (oldInt != nodeInt) {
        return FAIL;
    }

    // split the node
	group1.clear();
	group2.clear();
	lcm1.clear();
	lcm2.clear();

#ifdef _DEBUG_
	// Printing the node
	warnx << "------> ";
	for (int i = 0; i < (int) entries.size(); i++) {
		warnx << entries[i] << "        ";
	}
	warnx << "\n";
#endif
	
	splitNode(entries, group1, group2, lcm1, lcm2);

	// Original node ask it to delete the second part...
	// The new node, make sure it does not have the first part...
	// Then we can guarantee eventual correctness guarantee...
			
	// Key - already known
	// Format of value - <type=SPLIT><interval><group1><group2>
	Interval myInt, mySiblingInt;
	mySiblingInt.ln = nodeInt.ln + nodeInt.rn;
	mySiblingInt.ld = nodeInt.ld + nodeInt.rd;
	mySiblingInt.rn = nodeInt.rn;
	mySiblingInt.rd = nodeInt.rd;
	mySiblingInt.level = nodeInt.level;
			
	myInt.ln = nodeInt.ln;
	myInt.ld = nodeInt.ld;
	myInt.rn = mySiblingInt.ln;
	myInt.rd = mySiblingInt.ld;
    myInt.level = nodeInt.level;

	//warnx << "NODE LEVEL: " << nodeInt.level << "\n";
	
	// Key - new key from Interval -- includes level information
	// for uniqueness
	char tempBuf[128];
	sprintf(tempBuf, "%d.%d.%d", mySiblingInt.level, mySiblingInt.ln, mySiblingInt.ld);
	chordID siblingID;
	siblingID = compute_hash(tempBuf, strlen(tempBuf));
	strbuf s;
	s << siblingID;
	str newChildID = str(s);
			
	char *value;
	int valLen;

	char *hdrVal;
	int hdrLen;

	makeKeyValue(&hdrVal, hdrLen, nodeType, mySiblingInt, UPDATEHDRLOCK);

    //warnx << "Size group1: " << group1.size() << "\n";
    //warnx << "Size group2: " << group2.size() << "\n";
    
    warnx << "------ Performing Non Root Node Splitting -------\n";
    
	// step 1: Create sibling node
		
	DHTStatus stat = insertDHT(siblingID, hdrVal, hdrLen);
	cleanup(hdrVal);

	if (stat == FAIL) return FAIL;

    // This peer has authority to finish the split
    if (stat != NOTFIRST) {

        warnx << "I am the first!\n";
        
        // step 2: Insert contents to the newly created node...
        makeKeyValue(&value, valLen, entries, group2, SPLIT);

        stat = insertDHT(siblingID, value, valLen);
        cleanup(value);

        if (stat == FAIL) return FAIL;
        
        // step 3: Now update parent entry
        makeKeyValue(&value, valLen, newChildID, lcm2, UPDATE);
        DHTStatus stat = insertDHT(pID, value, valLen);
        cleanup(value);
        if (stat == FAIL) return FAIL;

        // step 3.1: Update the original parent entry
        strbuf o;
        o << ID;
        str myID = str(o);
        
        makeKeyValue(&value, valLen, myID, lcm1, REPLACESIG); 
        stat = insertDHT(pID, value, valLen);
        cleanup(value);
        
        if (stat == FAIL) return FAIL;
        

        // step 4: Next delete the moved contents from the original node
        makeKeyValue(&value, valLen, entries, group2, SPLIT);
        
        stat = insertDHT(ID, value, valLen);
        cleanup(value);
        
        if (stat == FAIL) return FAIL;
        
        // step 5: Update the header of the original node
        makeKeyValue(&hdrVal, hdrLen, nodeType, myInt, UPDATEHDR);
        
        stat = insertDHT(ID, hdrVal, hdrLen);
        cleanup(hdrVal);
        if (stat == FAIL) return FAIL;
    }
    else if (stat == NOTFIRST) { // Will await header change
        int waitInterval = 1;
        vec<str> myNodeEntries;
        
        while (1) {
            sleep(waitInterval);
            out = 0;
            nodeEntries.clear();
            retrieveError = false;
            
            dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));
            
            while (out == 0) acheck();
            
            if (retrieveError) {
                warnx << "Unable to read node " << ID << "\n";
                return FAIL;
            }
            
            warnx << "Number of entries: " << nodeEntries.size() << "\n";

            // Copy it -- currently no other solution
            myNodeEntries.clear();
            myNodeEntries = nodeEntries;

            str a, b;
            Interval currInt;
           
            warnx << "# of node entries: " << myNodeEntries.size() << "\n";
            
            getKeyValue(myNodeEntries[0], a, b);
            
           
            getInterval(b, currInt);

            // Check the header for change
            if (nodeInt == currInt) {
                waitInterval *= 2;    
            }
            else {
                warnx << "---- Non Root Node Header has changed -----\n";
                break;
            }
            
        }
    }

	return SUCC;
}

// non-leaf node splits may miss out some inserts during splitting... but
// will be corrected during the refresh phase by accessing child nodes
/*DHTStatus performSplitOld(chordID ID, vec<str>& entries, str& nodeType, Interval& nodeInt)
{
	chordID typeOfNode;
	str2chordID(nodeType, typeOfNode);
	
	// split the node
	group1.clear();
	group2.clear();
	lcm1.clear();
	lcm2.clear();

#ifdef _DEBUG_
	// Printing the node
	warnx << "------> ";
	for (int i = 0; i < (int) entries.size(); i++) {
		warnx << entries[i] << "        ";
	}
	warnx << "\n";
#endif
	
	splitNode(entries, group1, group2, lcm1, lcm2);

	// Original node ask it to delete the second part...
	// The new node, make sure it does not have the first part...
	// Then we can guarantee eventual correctness guarantee...
			
	// Key - already known
	// Format of value - <type=SPLIT><interval><group1><group2>
	Interval myInt, mySiblingInt;
	mySiblingInt.ln = nodeInt.ln + nodeInt.rn;
	mySiblingInt.ld = nodeInt.ld + nodeInt.rd;
	mySiblingInt.rn = nodeInt.rn;
	mySiblingInt.rd = nodeInt.rd;
	mySiblingInt.level = nodeInt.level;
			
	myInt.ln = nodeInt.ln;
	myInt.ld = nodeInt.ld;
	myInt.rn = mySiblingInt.ln;
	myInt.rd = mySiblingInt.ld;

	//warnx << "NODE LEVEL: " << nodeInt.level << "\n";
	
	// Key - new key from Interval -- includes level information
	// for uniqueness
	char tempBuf[128];
	sprintf(tempBuf, "%d.%d.%d", mySiblingInt.level, mySiblingInt.ln, mySiblingInt.ld);
	chordID siblingID;
	siblingID = compute_hash(tempBuf, strlen(tempBuf));
	strbuf s;
	s << siblingID;
	str newChildID = str(s);

			
	char *value;
	int valLen;

        // First insert/create new node

	// First update the header information - type and interval
	char *hdrVal;
	int hdrLen;

	makeKeyValue(&hdrVal, hdrLen, nodeType, mySiblingInt, UPDATEHDR);
			
	// Insert existing node
	// First header
			
	DHTStatus stat = insertDHT(ID, hdrVal, hdrLen);
	cleanup(hdrVal);

	if (stat == FAIL) return FAIL;

	// Need to do this only for the nonleaf node... since root is
	// taken care of by creating two new child nodes.
	// for non-leaf the new entry may by assigned to the original node!!!
	
	// First check if the new entry actually exists in group2
	InsertType myType = SPLIT;

	if (typeOfNode != LEAF) {
		for (int i = 0; i < (int) group1.size(); i++) {
			if (group1[i] == (int) entries.size() - 1) {
				myType = SPLITSPECIAL;
				group2.insert(group2.begin(), group1[i]);
				break;
			}
		}
	}

#ifdef _DEBUG_
	warnx << "Group2 ";
	// Print the entries in group2
	for (int i = 0; i < (int) group2.size(); i++) {
		warnx << group2[i] << " ";
	}
	warnx << "\n";
#endif
	// Next the contents
	makeKeyValue(&value, valLen, entries, group2, myType);

	stat = insertDHT(ID, value, valLen);
	cleanup(value);

	if (stat == FAIL) return FAIL;

	// readjust group2
	if (myType == SPLITSPECIAL) {
		group2.erase(group2.begin());
	}
	
	// First update the header information - type and interval
	// Insert sibling node
			
	makeKeyValue(&hdrVal, hdrLen, nodeType, mySiblingInt, UPDATEHDR);

	// First header
	stat = insertDHT(siblingID, hdrVal, hdrLen);
	cleanup(hdrVal);

	if (stat == FAIL) return FAIL;
			
	// Then node contents
	// Next the contents
	makeKeyValue(&value, valLen, entries, group2, SPLIT);

	stat = insertDHT(siblingID, value, valLen);
	cleanup(value);

	if (stat == FAIL) return FAIL;
			
	return NODESPLIT;
}
*/

// Inserts a document signature into a dynamic signature index.
// Format of each node: <type/interval><key/ptr><key/ptr>...
//
// A few scenarios are taken into consideration --
// a) Two clients (or more) read a full page and decide to split them
// b) A client thinks a page has space and tries to insert, then
//    in the mean time another client/s have already inserted keys and
//    made it full, then the node that stores it can return an error,
//    in which case, that node can be read again and verified and if it is
//    full it will be split!!! so works fine...
// c) if there is space and (a) and (b) are not true, then just insert!!!
//
// Note that we have an assumption that there is no merging and no deletion.
// Once a node is created, it is never deleted.
// Hence once two sets decide to part, they never come close!!!
// This will be exploited to make matters simple!!!
//
// Periodically each peer containing a node should perform the "REFRESH PHASE"
// where it quries it's child nodes and gets their latest lcm() and updates its
// signature.
//
// Semantics:
// (a) UPDATE - compute lcm with the existing key or adds a new one if absent
// (b) SPLIT - if node is full -- then delete the passed elements
//             if node is empty -- then add the passed elements
//             otherwise -- do nothing (do some verification may be)
// (c) UPDATEHDR - updates header -- if the level is at least as large as before and
//                                   the right interval boundary is at least as small
//                                   as before.
DHTStatus insertDocument(str& nodeID, std::vector<POLY>& sig, int docid)
{
	vec<str> myNodeEntries;
	chordID ID;
	str2chordID(nodeID, ID);

    nodeEntries.clear();
	// now fetch the node
	out = 0;
	retrieveError = false;
	
	dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));

	while (out == 0) acheck();

	if (retrieveError) {
		warnx << "Failed to retrieve key during insertion...\n";
		return FAIL;
	}

	// Copy it -- currently no other solution
	myNodeEntries = nodeEntries;

	str a, b;
	Interval nodeInt;
	chordID nodeType;
	warnx << "# of node entries: " << myNodeEntries.size() << "\n";
	
	getKeyValue(myNodeEntries[0], a, b);

	str2chordID(a, nodeType);
	getInterval(b, nodeInt);

	DHTStatus status = FAIL;
	
	if (nodeType == LEAF) {
        warnx << "------------- VISITING Leaf Node --------------\n";
        
		// Full
		if ((int) myNodeEntries.size() > MAXENTRIES) {
            fullNodeIDs.push_back(ID);
            fullNodeInts.push_back(nodeInt);
            status = NODESPLIT;
		}
		else {
            // insert key
            warnx << " +++++ Inserting signature into leaf node +++++\n";
			char *value;
			int valLen;
			char docidstr[128];
			sprintf(docidstr, "%d", docid);
			str dockey(docidstr, strlen(docidstr));
			makeKeyValue(&value, valLen, dockey, sig, UPDATE);

			DHTStatus stat = insertDHT(ID, value, valLen);
			cleanup(value);
			if (stat == FAIL) return FAIL;
			status = SUCC;
		}
	}
	else if (nodeType == NONLEAF || nodeType == ROOT) {
		str childID = pickChild(myNodeEntries, sig);

        if (nodeType == ROOT) {
            warnx << "---------------- VISITING Root Node -----------------\n";
        }
        else {
            warnx << "---------------- VISITING Non Leaf Node -----------------\n";
        }
		assert(childID != "NULL");
		warnx << "===> Child picked for insertion: " << childID << "\n";
		
		status = insertDocument(childID, sig, docid);

        //warnx << "Finished lower level insert...\n";
        
		if (status == FAIL) {
			warnx << "Inserting failed...\n";
			return status;
		}
		else if (status == REINSERT) {
			return status;
		}
		else if (status == NODESPLIT) {
            if (nodeType != ROOT && (int) myNodeEntries.size() > MAXENTRIES) {
                fullNodeIDs.push_back(ID);
                fullNodeInts.push_back(nodeInt);
                //warnx << "Full size: " << fullNodeInts.size() << "\n";
                status = NODESPLIT;
            }
            else {

                // Split ROOT if reqd
                if (nodeType == ROOT && (int) myNodeEntries.size() > MAXENTRIES) {
                    performSplitRoot(ID, nodeInt);
                }
                
                // Go thro the list of full nodes and split it
                // Actually need to store the original headers
                chordID pID = ID;
                for (int i = 0; i < (int) fullNodeIDs.size(); i++) {
                    performSplit(fullNodeIDs[i], fullNodeInts[i], pID);
                    pID = fullNodeIDs[i];
                }
                status = REINSERT; // We will REINSERT from the root for now
            }
        }
        else if (status == SUCC) {

            warnx << "++++++ Updating parent node signature +++++ \n";
            char *value;
			int valLen;
			makeKeyValue(&value, valLen, childID, sig, UPDATEIFPRESENT);
            
			DHTStatus stat = insertDHT(ID, value, valLen);
			cleanup(value);
            
			if (stat == FAIL) return FAIL;
            
			status = SUCC;
        }
    }
	else {
		warnx << "Corrupt node header...\n";
		assert(0);
	}

	return status;
}

// Query processing stage.
void queryProcess(str &nodeID, std::vector<std::vector<POLY> >& listOfSigs)
{
	vec<str> entriesToProcess;
	chordID ID;
	str2chordID(nodeID, ID);

	bool inCache;
	int pinnedNodeId;

	std::string nId = getString(nodeID);
	if (listOfVisitedNodes.find(nId) != listOfVisitedNodes.end()) {
		return;
	}

    // No cache used
    if (cacheSize == 0) {
        inCache = false;
    }
    else {
        inCache = findInCache(nodeID, pinnedNodeId);
    }
    
	// If not in cache, read from DHT
	if (inCache) {
		//warnx << "In cache...\n";
		cacheHits++;
		// Copy the entries
		for (int i = 0; i < (int) nodeCache[pinnedNodeId].second.size(); i++) {
			entriesToProcess.push_back(nodeCache[pinnedNodeId].second[i]);
		}

		listOfVisitedNodes[nId] = true;
	}
	else {
		out = 0;
		nodeEntries.clear();
		retrieveError = false;
		
		double beginRetrieveTime = getgtod();
		dhash->retrieve(ID, DHASH_NOAUTH, wrap(fetch_cb));
		
		while (out == 0) acheck();
		
		if (retrieveError) {
			warnx << "Unable to read node " << ID << "\n";
			return;
		}

		double endRetrieveTime = getgtod();
		listOfVisitedNodes[nId] = true;
		
		warnx << "Key retrieved: " << ID << "\n";
		std::cout <<" Key retrieve time: "
							<< endRetrieveTime - beginRetrieveTime << std::endl;
		
		warnx << "Number of entries: " << nodeEntries.size() << "\n";
		entriesToProcess = nodeEntries;
        // If cache is used
        if (cacheSize > 0) {
            // store in cache
            std::vector<str> e;
            for (int i = 0; i < (int) entriesToProcess.size(); i++) {
                e.push_back(entriesToProcess[i]);
            }
            
            bool found = findReplacement(nodeID, e, pinnedNodeId);
            assert(found);
        }
	}
	
#ifdef _DEBUG_
	for (int i = 0; i < (int) nodeEntries.size(); i++) {
		dataReadSize += nodeEntries[i].len();
	}

#endif

	str a, b;
	Interval nodeInt;
	chordID nodeType;
	
	getKeyValue(entriesToProcess[0], a, b);

	str2chordID(a, nodeType);
	getInterval(b, nodeInt);
	
	std::vector<POLY> rem;
	std::vector<POLY> entrySig;
	str childKey;

	// Read the node and select those childptrs that are divided by
	// sig...
	for (int i = 1; i < (int) entriesToProcess.size(); i++) {
		entrySig.clear();
		getKeyValue(entriesToProcess[i].cstr(), childKey, entrySig);

		//warnx << "Child key: " << childKey << "\n";
		// Need to test for each signature in the listOfSigs...
		// An implicit OR predicate is assumed...
		int dega, degb;
		dega = getDegree(entrySig);
		//warnx << "Degree of entry: " << dega << "\n";	
#ifdef _DEBUG_
		warnx << "Deg a: " << dega << "\n";
		for (int j = 0; j < (int) entrySig.size(); j++) {
			warnx << entrySig[j] << " ";
		}
		warnx << "\n";
#endif
		
		std::vector<std::vector<POLY> > newListOfSigs;
		bool isDivides = false;
		for (int q = 0; q < (int) listOfSigs.size(); q++) {
			if (q == 0) {
				newListOfSigs = listOfSigs;
			}
			// Test for divisibility!!!
			rem.clear();
			degb = getDegree(listOfSigs[q]);
			//warnx << "Deg b: " << degb << "\n";
			//double beginRemTime = getgtod();
			if (dega >= degb) {
				remainder(rem, entrySig, listOfSigs[q]);
			}

			//double endRemTime = getgtod();
			//std::cout << "Division time: " << endRemTime - beginRemTime << "\n";
			
			if (rem.size() == 1 && rem[0] == (POLY) 0) {
				//warnx << "Break point: " << q << "\n";
				isDivides = true;
				break;
			}

			// Mark as not to be checked again
			newListOfSigs.erase(newListOfSigs.begin());
		}

		// If the division is successful, i.e., remainder = 0
		if (isDivides) {
			if (nodeType == LEAF) {
				numDocs++;
				//warnx << "==== Found match. Docid = " << childKey << " =====\n";
			}
			else {
				queryProcess(childKey, newListOfSigs);
			}
		}
	}

	// Unpin the page
	unpinNode(pinnedNodeId);
	return;
}


									 
// Compute the number of replicas based on the current level and
// maximum tree depth...
int getNumReplicas(int level, int maxTreeDepth)
{
	return (maxTreeDepth - level);
}

 
